
████████╗░█████╗░███████╗
╚══██╔══╝██╔══██╗██╔════╝
░░░██║░░░██║░░╚═╝█████╗░░
░░░██║░░░██║░░██╗██╔══╝░░
░░░██║░░░╚█████╔╝██║░░░░░
░░░╚═╝░░░░╚════╝░╚═╝░░░░░
This is a my new malware
Create in MSVCP 2022
Working in xp-11
Non-safety version reg delete HKCU
The developer is not responsible for any damage caused by this Trojan; 
it is recommended to run it within a virtual machine using a snapshot. 
Running it on a physical PC is done at your own risk.